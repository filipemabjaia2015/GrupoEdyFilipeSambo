-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 03-Dez-2015 às 22:53
-- Versão do servidor: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dk`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE IF NOT EXISTS `eventos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  `local` varchar(200) NOT NULL,
  `agenda` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`id`, `titulo`, `tipo`, `descricao`, `local`, `agenda`, `created_at`, `updated_at`) VALUES
(1, '', '', '', '', '', '2015-12-03 19:02:29', '2015-12-03 19:02:29'),
(2, 'Festa', 'Batizado', 'da menina ju', 'matola', 'comeca as 14 e termina 22', '2015-12-03 21:33:57', '0000-00-00 00:00:00'),
(3, 'Festa', 'Casamento', 'do joao e Maria', 'Mozal', 'inicio as 12 fim as 23horas', '2015-12-03 21:34:59', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `participantes`
--

CREATE TABLE IF NOT EXISTS `participantes` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `apelido` varchar(200) NOT NULL,
  `grau_academico` varchar(200) NOT NULL,
  `empresa` varchar(200) NOT NULL,
  `idade` varchar(200) NOT NULL,
  `sexo` varchar(200) NOT NULL,
  `contacto` int(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tipo` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `participantes`
--

INSERT INTO `participantes` (`id`, `nome`, `apelido`, `grau_academico`, `empresa`, `idade`, `sexo`, `contacto`, `email`, `created_at`, `updated_at`, `tipo`) VALUES
(1, '', '', '', '', '', '', 0, '', '2015-12-03 19:04:09', '2015-12-03 19:04:09', ''),
(2, '', '', '', '', '', '', 0, '', '2015-12-03 19:32:26', '2015-12-03 19:32:26', ''),
(3, 'Filipe', 'Mabjaia', '12', 'DK', '25', 'Male', 849905040, 'filipegilmbj@gmail.com', '2015-12-03 21:37:02', '0000-00-00 00:00:00', 'orador'),
(4, 'Lipe', 'Mabj', '10', 'DK', '30', 'Male', 825846614, 'fil@gmail.com', '2015-12-03 21:37:02', '0000-00-00 00:00:00', 'convidado especial');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `updated_at`, `created_at`) VALUES
(1, 'filipe', '$2y$10$oqh//XQKRMGAE3H1.z5k0eGLmBbfNhZc6ImEhX0OgrY5rpGRvTRrO', 'filipegilmbj@gmail.com', '2015-12-03 18:40:52', '2015-12-03 18:40:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participantes`
--
ALTER TABLE `participantes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `participantes`
--
ALTER TABLE `participantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'WelcomeController@index');

Route::get('home', 'HomeController@index');
//Route::get('eventos', 'EventoController@index');

Route::resource('eventos','EventoController');

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);


Route::resource('students', 'StudentController');

Route::get('students/{id}/delete', [
    'as' => 'students.delete',
    'uses' => 'StudentController@destroy',
]);


Route::resource('eventos', 'EventoController');

Route::get('eventos/{id}/delete', [
    'as' => 'eventos.delete',
    'uses' => 'EventoController@destroy',
]);


Route::resource('oradors', 'oradorController');

Route::get('oradors/{id}/delete', [
    'as' => 'oradors.delete',
    'uses' => 'oradorController@destroy',
]);


Route::resource('participantes', 'ParticipantesController');

Route::get('participantes/{id}/delete', [
    'as' => 'participantes.delete',
    'uses' => 'ParticipantesController@destroy',
]);


Route::resource('participantes', 'ParticipantesController');

Route::get('participantes/{id}/delete', [
    'as' => 'participantes.delete',
    'uses' => 'ParticipantesController@destroy',
]);

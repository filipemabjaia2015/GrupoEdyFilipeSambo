<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Requests\CreateParticipantesRequest;
use Illuminate\Http\Request;
use App\Libraries\Repositories\ParticipantesRepository;
use Mitul\Controller\AppBaseController;
use Response;
use Flash;

class ParticipantesController extends AppBaseController
{

	/** @var  ParticipantesRepository */
	private $participantesRepository;

	function __construct(ParticipantesRepository $participantesRepo)
	{
		$this->participantesRepository = $participantesRepo;
	}

	/**
	 * Display a listing of the Participantes.
	 *
	 * @param Request $request
	 *
	 * @return Response
	 */
	public function index(Request $request)
	{
	    $input = $request->all();

		$result = $this->participantesRepository->search($input);

		$participantes = $result[0];

		$attributes = $result[1];

		return view('participantes.index')
		    ->with('participantes', $participantes)
		    ->with('attributes', $attributes);;
	}

	/**
	 * Show the form for creating a new Participantes.
	 *
	 * @return Response
	 */
	public function create()
	{
		return view('participantes.create');
	}

	/**
	 * Store a newly created Participantes in storage.
	 *
	 * @param CreateParticipantesRequest $request
	 *
	 * @return Response
	 */
	public function store(CreateParticipantesRequest $request)
	{
        $input = $request->all();

		$participantes = $this->participantesRepository->store($input);

		Flash::message('Participantes saved successfully.');

		return redirect(route('participantes.index'));
	}

	/**
	 * Display the specified Participantes.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function show($id)
	{
		$participantes = $this->participantesRepository->findParticipantesById($id);

		if(empty($participantes))
		{
			Flash::error('Participantes not found');
			return redirect(route('participantes.index'));
		}

		return view('participantes.show')->with('participantes', $participantes);
	}

	/**
	 * Show the form for editing the specified Participantes.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$participantes = $this->participantesRepository->findParticipantesById($id);

		if(empty($participantes))
		{
			Flash::error('Participantes not found');
			return redirect(route('participantes.index'));
		}

		return view('participantes.edit')->with('participantes', $participantes);
	}

	/**
	 * Update the specified Participantes in storage.
	 *
	 * @param  int    $id
	 * @param CreateParticipantesRequest $request
	 *
	 * @return Response
	 */
	public function update($id, CreateParticipantesRequest $request)
	{
		$participantes = $this->participantesRepository->findParticipantesById($id);

		if(empty($participantes))
		{
			Flash::error('Participantes not found');
			return redirect(route('participantes.index'));
		}

		$participantes = $this->participantesRepository->update($participantes, $request->all());

		Flash::message('Participantes updated successfully.');

		return redirect(route('participantes.index'));
	}

	/**
	 * Remove the specified Participantes from storage.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function destroy($id)
	{
		$participantes = $this->participantesRepository->findParticipantesById($id);

		if(empty($participantes))
		{
			Flash::error('Participantes not found');
			return redirect(route('participantes.index'));
		}

		$participantes->delete();

		Flash::message('Participantes deleted successfully.');

		return redirect(route('participantes.index'));
	}

}

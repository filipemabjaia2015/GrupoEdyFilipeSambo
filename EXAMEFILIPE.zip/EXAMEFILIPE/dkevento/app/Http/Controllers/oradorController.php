<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Requests\CreateoradorRequest;
use App\Models\orador;
use Illuminate\Http\Request;
use Mitul\Controller\AppBaseController;
use Response;
use Flash;
use Schema;

class oradorController extends AppBaseController
{

	/**
	 * Display a listing of the Post.
	 *
	 * @param Request $request
	 *
	 * @return Response
	 */
	public function index(Request $request)
	{
		$query = orador::query();
        $columns = Schema::getColumnListing('$TABLE_NAME$');
        $attributes = array();

        foreach($columns as $attribute){
            if($request[$attribute] == true)
            {
                $query->where($attribute, $request[$attribute]);
                $attributes[$attribute] =  $request[$attribute];
            }else{
                $attributes[$attribute] =  null;
            }
        };

        $oradors = $query->get();

        return view('oradors.index')
            ->with('oradors', $oradors)
            ->with('attributes', $attributes);
	}

	/**
	 * Show the form for creating a new orador.
	 *
	 * @return Response
	 */
	public function create()
	{
		return view('oradors.create');
	}

	/**
	 * Store a newly created orador in storage.
	 *
	 * @param CreateoradorRequest $request
	 *
	 * @return Response
	 */
	public function store(CreateoradorRequest $request)
	{
        $input = $request->all();

		$orador = orador::create($input);

		Flash::message('orador saved successfully.');

		return redirect(route('oradors.index'));
	}

	/**
	 * Display the specified orador.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function show($id)
	{
		$orador = orador::find($id);

		if(empty($orador))
		{
			Flash::error('orador not found');
			return redirect(route('oradors.index'));
		}

		return view('oradors.show')->with('orador', $orador);
	}

	/**
	 * Show the form for editing the specified orador.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$orador = orador::find($id);

		if(empty($orador))
		{
			Flash::error('orador not found');
			return redirect(route('oradors.index'));
		}

		return view('oradors.edit')->with('orador', $orador);
	}

	/**
	 * Update the specified orador in storage.
	 *
	 * @param  int    $id
	 * @param CreateoradorRequest $request
	 *
	 * @return Response
	 */
	public function update($id, CreateoradorRequest $request)
	{
		/** @var orador $orador */
		$orador = orador::find($id);

		if(empty($orador))
		{
			Flash::error('orador not found');
			return redirect(route('oradors.index'));
		}

		$orador->fill($request->all());
		$orador->save();

		Flash::message('orador updated successfully.');

		return redirect(route('oradors.index'));
	}

	/**
	 * Remove the specified orador from storage.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function destroy($id)
	{
		/** @var orador $orador */
		$orador = orador::find($id);

		if(empty($orador))
		{
			Flash::error('orador not found');
			return redirect(route('oradors.index'));
		}

		$orador->delete();

		Flash::message('orador deleted successfully.');

		return redirect(route('oradors.index'));
	}
}

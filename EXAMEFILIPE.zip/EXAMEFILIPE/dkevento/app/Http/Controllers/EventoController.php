<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Requests\CreateEventoRequest;
use App\Models\Evento;
use Illuminate\Http\Request;
use Mitul\Controller\AppBaseController;
use Response;
use Flash;
use Schema;

class EventoController extends AppBaseController
{

	/**
	 * Display a listing of the Post.
	 *
	 * @param Request $request
	 *
	 * @return Response
	 */
	public function index(Request $request)
	{
		$query = Evento::query();
        $columns = Schema::getColumnListing('$TABLE_NAME$');
        $attributes = array();

        foreach($columns as $attribute){
            if($request[$attribute] == true)
            {
                $query->where($attribute, $request[$attribute]);
                $attributes[$attribute] =  $request[$attribute];
            }else{
                $attributes[$attribute] =  null;
            }
        };

        $eventos = $query->get();

        return view('eventos.index')
            ->with('eventos', $eventos)
            ->with('attributes', $attributes);
	}

	/**
	 * Show the form for creating a new Evento.
	 *
	 * @return Response
	 */
	public function create()
	{
		return view('eventos.create');
	}

	/**
	 * Store a newly created Evento in storage.
	 *
	 * @param CreateEventoRequest $request
	 *
	 * @return Response
	 */
	public function store(CreateEventoRequest $request)
	{
			$data = Request::all();
			$rules = array (
			
			'titulo' => 'required',
			'tipo' => 'required',
			'descricao' => 'required',
			'local' => 'required',
			'agenda' => 'required',
			);
	
			$v = validator::make($data, $rules);
			
			if ($v -> fails()){
			
				return redirect()-> back()
				-> withErrors($v-> erros())
				->withInput(Request::except('titulo'));
			}
			
	
        $input = $request->all();

		$evento = Evento::create($input);

		Flash::message('Evento saved successfully.');

		return redirect(route('eventos.index'));
	}

	/**
	 * Display the specified Evento.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function show($id)
	{
		$evento = Evento::find($id);

		if(empty($evento))
		{
			Flash::error('Evento not found');
			return redirect(route('eventos.index'));
		}

		return view('eventos.show')->with('evento', $evento);
	}

	/**
	 * Show the form for editing the specified Evento.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$evento = Evento::find($id);

		if(empty($evento))
		{
			Flash::error('Evento not found');
			return redirect(route('eventos.index'));
		}

		return view('eventos.edit')->with('evento', $evento);
	}

	/**
	 * Update the specified Evento in storage.
	 *
	 * @param  int    $id
	 * @param CreateEventoRequest $request
	 *
	 * @return Response
	 */
	public function update($id, CreateEventoRequest $request)
	{
		/** @var Evento $evento */
		$evento = Evento::find($id);

		if(empty($evento))
		{
			Flash::error('Evento not found');
			return redirect(route('eventos.index'));
		}

		$evento->fill($request->all());
		$evento->save();

		Flash::message('Evento updated successfully.');

		return redirect(route('eventos.index'));
	}

	/**
	 * Remove the specified Evento from storage.
	 *
	 * @param  int $id
	 *
	 * @return Response
	 */
	public function destroy($id)
	{
		/** @var Evento $evento */
		$evento = Evento::find($id);

		if(empty($evento))
		{
			Flash::error('Evento not found');
			return redirect(route('eventos.index'));
		}

		$evento->delete();

		Flash::message('Evento deleted successfully.');

		return redirect(route('eventos.index'));
	}
}

<?php

namespace App\Libraries\Repositories;


use App\Models\Participantes;
use Illuminate\Support\Facades\Schema;

class ParticipantesRepository
{

	/**
	 * Returns all Participantes
	 *
	 * @return \Illuminate\Database\Eloquent\Collection|static[]
	 */
	public function all()
	{
		return Participantes::all();
	}

	public function search($input)
    {
        $query = Participantes::query();

        $columns = Schema::getColumnListing('participantes');
        $attributes = array();

        foreach($columns as $attribute){
            if(isset($input[$attribute]))
            {
                $query->where($attribute, $input[$attribute]);
                $attributes[$attribute] =  $input[$attribute];
            }else{
                $attributes[$attribute] =  null;
            }
        };

        return [$query->get(), $attributes];

    }

	/**
	 * Stores Participantes into database
	 *
	 * @param array $input
	 *
	 * @return Participantes
	 */
	public function store($input)
	{
		return Participantes::create($input);
	}

	/**
	 * Find Participantes by given id
	 *
	 * @param int $id
	 *
	 * @return \Illuminate\Support\Collection|null|static|Participantes
	 */
	public function findParticipantesById($id)
	{
		return Participantes::find($id);
	}

	/**
	 * Updates Participantes into database
	 *
	 * @param Participantes $participantes
	 * @param array $input
	 *
	 * @return Participantes
	 */
	public function update($participantes, $input)
	{
		$participantes->fill($input);
		$participantes->save();

		return $participantes;
	}
}
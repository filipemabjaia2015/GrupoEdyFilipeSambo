<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    
	public $table = "eventos";

	public $primaryKey = "id";
    
	public $timestamps = true;

	public $fillable = [
	    "Titulo",
		"Tipo",
		"Descricao",
		"Local",
		"Agenda"
	];

	public static $rules = [
	    "Titulo" => "requered",
		"Tipo" => "requered",
		"Descricao" => "requered",
		"Local" => "requered",
		"Agenda" => "requered"
	];

}

<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class orador extends Model
{
    
	public $table = "oradors";

	public $primaryKey = "id";
    
	public $timestamps = true;

	public $fillable = [
	    "Agenda"
	];

	public static $rules = [
	    "Agenda" => "requered"
	];

}

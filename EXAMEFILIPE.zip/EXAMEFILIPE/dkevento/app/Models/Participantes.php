<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Participantes extends Model
{
    
	public $table = "participantes";

	public $primaryKey = "id";
    
	public $timestamps = true;

	public $fillable = [
	    "Nome",
		"Apelido",
		"Grau_Academico",
		"Empresa",
		"Idade",
		"Sexo",
		"Contacto",
		"Email",
		"Tipo"
	];

	public static $rules = [
	    "Nome" => "requered",
		"Apelido" => "requered",
		"Grau_Academico" => "requered",
		"Empresa" => "requered",
		"Idade" => "requered",
		"Sexo" => "requered",
		"Contacto" => "requered",
		"Email" => "requered",
		"Tipo" => "requered"
	];

}

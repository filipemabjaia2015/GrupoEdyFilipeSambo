<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    
	public $table = "students";

	public $primaryKey = "id";
    
	public $timestamps = true;

	public $fillable = [
	    "name",
		"name",
		"email",
		"phone",
		"address",
		"max"
	];

	public static $rules = [
	    "name" => "required",
		"email" => "required|unique:students",
		"phone" => "required",
		"address" => "max:300",
		"max" => "max:300|"
	];

}

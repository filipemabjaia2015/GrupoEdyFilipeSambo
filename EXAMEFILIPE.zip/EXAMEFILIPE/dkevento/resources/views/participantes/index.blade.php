@extends('app')

@section('content')

    <div class="container">

        @include('flash::message')

        <div class="row">
            <h1 class="pull-left">Participantes</h1>
            <a class="btn btn-primary pull-right" style="margin-top: 25px" href="{!! route('participantes.create') !!}">Add New</a>
        </div>

        <div class="row">
            @if($participantes->isEmpty())
                <div class="well text-center">No Participantes found.</div>
            @else
                <table class="table">
                    <thead>
                    <th>Nome</th>
			<th>Apelido</th>
			<th>Grau Academico</th>
			<th>Empresa</th>
			<th>Idade</th>
			<th>Sexo</th>
			<th>Contacto</th>
			<th>Email</th>
			<th>Tipo</th>
                    <th width="50px">Action</th>
                    </thead>
                    <tbody>
                     
                    @foreach($participantes as $participantes)
                        <tr>
                            <td>{!! $participantes->Nome !!}</td>
					<td>{!! $participantes->Apelido !!}</td>
					<td>{!! $participantes->Grau_Academico !!}</td>
					<td>{!! $participantes->Empresa !!}</td>
					<td>{!! $participantes->Idade !!}</td>
					<td>{!! $participantes->Sexo !!}</td>
					<td>{!! $participantes->Contacto !!}</td>
					<td>{!! $participantes->Email !!}</td>
					<td>{!! $participantes->Tipo !!}</td>
                            <td>
                                <a href="{!! route('participantes.edit', [$participantes->id]) !!}"><i class="glyphicon glyphicon-edit"></i></a>
                                <a href="{!! route('participantes.delete', [$participantes->id]) !!}" onclick="return confirm('Are you sure wants to delete this Participantes?')"><i class="glyphicon glyphicon-remove"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @endif
        </div>
    </div>
@endsection
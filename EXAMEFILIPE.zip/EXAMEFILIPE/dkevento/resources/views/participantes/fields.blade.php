<!--- Nome Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Nome', 'Nome:') !!}
    {!! Form::text('Nome', null, ['class' => 'form-control']) !!}
</div>

<!--- Apelido Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Apelido', 'Apelido:') !!}
    {!! Form::text('Apelido', null, ['class' => 'form-control']) !!}
</div>

<!--- Grau Academico Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Grau_Academico', 'Grau Academico:') !!}
    {!! Form::text('Grau_Academico', null, ['class' => 'form-control']) !!}
</div>

<!--- Empresa Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Empresa', 'Empresa:') !!}
    {!! Form::text('Empresa', null, ['class' => 'form-control']) !!}
</div>

<!--- Idade Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Idade', 'Idade:') !!}
    {!! Form::text('Idade', null, ['class' => 'form-control']) !!}
</div>

<!--- Sexo Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Sexo', 'Sexo:') !!}
    {!! Form::text('Sexo', null, ['class' => 'form-control']) !!}
</div>

<!--- Contacto Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Contacto', 'Contacto:') !!}
    {!! Form::text('Contacto', null, ['class' => 'form-control']) !!}
</div>

<!--- Email Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Email', 'Email:') !!}
    {!! Form::text('Email', null, ['class' => 'form-control']) !!}
</div>

<!--- Tipo Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Tipo', 'Tipo:') !!}
    {!! Form::text('Tipo', null, ['class' => 'form-control']) !!}
</div>


<!--- Submit Field --->
<div class="form-group col-sm-12">
    {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
</div>

@extends('app')

@section('content')
<div class="container">

    @include('common.errors')

    {!! Form::model($participantes, ['route' => ['participantes.update', $participantes->id], 'method' => 'patch']) !!}

        @include('participantes.fields')

    {!! Form::close() !!}
</div>
@endsection

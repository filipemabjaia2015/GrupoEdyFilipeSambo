@extends('app')

@section('content')
<div class="container">

    @include('common.errors')

    {!! Form::model($orador, ['route' => ['oradors.update', $orador->id], 'method' => 'patch']) !!}

        @include('oradors.fields')

    {!! Form::close() !!}
</div>
@endsection

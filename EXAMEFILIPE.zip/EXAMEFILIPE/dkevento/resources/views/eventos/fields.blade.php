<!--- Titulo Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Titulo', 'Titulo:') !!}
    {!! Form::text('Titulo', null, ['class' => 'form-control']) !!}
</div>

<!--- Tipo Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Tipo', 'Tipo:') !!}
    {!! Form::text('Tipo', null, ['class' => 'form-control']) !!}
</div>

<!--- Descricao Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Descricao', 'Descricao:') !!}
    {!! Form::text('Descricao', null, ['class' => 'form-control']) !!}
</div>

<!--- Local Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Local', 'Local:') !!}
    {!! Form::text('Local', null, ['class' => 'form-control']) !!}
</div>

<!--- Agenda Field --->
<div class="form-group col-sm-6 col-lg-4">
    {!! Form::label('Agenda', 'Agenda:') !!}
    {!! Form::text('Agenda', null, ['class' => 'form-control']) !!}
</div>


<!--- Submit Field --->
<div class="form-group col-sm-12">
    {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
</div>
<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateParticipantesTable extends Migration
{

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('participantes', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('Nome')->nullable();
			$table->string('Apelido')->nullable();
			$table->string('Grau_Academico')->nullable();
			$table->string('Empresa')->nullable();
			$table->string('Idade')->nullable();
			$table->string('Sexo')->nullable();
			$table->string('Contacto')->nullable();
			$table->string('Email')->nullable();
			$table->string('Tipo')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('participantes');
	}

}

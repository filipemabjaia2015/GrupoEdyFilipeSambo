<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
        protected $fillable=[
        'titulo',
        'tipo',
        'descricao',
        'local',
        'agenda'
    ];
	
}

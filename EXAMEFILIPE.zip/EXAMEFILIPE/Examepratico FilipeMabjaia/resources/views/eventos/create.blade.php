
    <h1>Criar Evento</h1>
    {!! Form::open(['url' => 'eventos']) !!}
    <div class="form-group">
        {!! Form::label('Titulo', 'Titulo:') !!}
        {!! Form::text('titulo',null,['class'=>'form-control']) !!}

        {!! Form::label('Tipo', 'Tipo:') !!}
        {!! Form::text('tipo',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Descricao', 'Descricao:') !!}
        {!! Form::text('descricao',null,['class'=>'form-control']) !!}

        {!! Form::label('Local', 'Local:') !!}
        {!! Form::text('local',null,['class'=>'form-control']) !!}

        {!! Form::label('Agenda', 'Agenda:') !!}
        {!! Form::text('agenda',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
		{!! Form::reset('Limpar', ['class' => 'btn btn-danger']) !!}
    </div>
    {!! Form::close() !!}

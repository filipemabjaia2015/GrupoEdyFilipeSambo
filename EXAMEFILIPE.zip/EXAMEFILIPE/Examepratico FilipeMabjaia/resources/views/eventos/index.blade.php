@extends('layout/template')

@section('content')
 <h1>DK Eventos</h1>
 <a href="{{url('/eventos/create')}}" class="btn btn-success">Criar Evento</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>Id</th>
         <th>Titulo</th>
         <th>Tipo</th>
         <th>Descricao</th>
         <th>Local</th>
         <th>Agenda</th>
         <th colspan="3">Actions</th>
     </tr>
     </thead>
     <tbody>
     @foreach ($eventos as $evento)
         <tr>
             <td>{{ $evento->id }}</td>
             <td>{{ $evento->titulo }}</td>
             <td>{{ $evento->tipo }}</td>
             <td>{{ $evento->decricao }}</td>
             <td>{{ $evento->local }}</td>
			 <td>{{ $evento->agenda }}</td>
             <td><img src="{{asset('img/'.$evento->image.'.jpg')}}" height="35" width="30"></td>
             <td><a href="{{url('eventos',$evento->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('eventos.edit',$evento->id)}}" class="btn btn-warning">Update</a></td>
             <td>
             {!! Form::open(['method' => 'DELETE', 'route'=>['eventos.destroy', $evento->id]]) !!}
             {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
             {!! Form::close() !!}
             </td>
         </tr>
     @endforeach

     </tbody>

 </table>
@endsection
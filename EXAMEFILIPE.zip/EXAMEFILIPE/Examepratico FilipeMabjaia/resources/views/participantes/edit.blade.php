@extends('layout.template')
@section('content')
    <h1>Actualizar Participante</h1>
    {!! Form::model($participante,['method' => 'PATCH','route'=>['participantes.update',$participante->id]]) !!}
    <div class="form-group">
        {!! Form::label('Nome', 'Nome:') !!}
        {!! Form::text('nome',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Apelido', 'Apelido:') !!}
        {!! Form::text('apelido',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Nivel', 'Nivel:') !!}
        {!! Form::text('nivel',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Empresa', 'Empresa:') !!}
        {!! Form::text('empresa',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Genero', 'Genero:') !!}
        {!! Form::text('genero',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Idade', 'Idade:') !!}
        {!! Form::text('idade',null,['class'=>'form-control']) !!}
    </div>	
    <div class="form-group">
        {!! Form::label('Email', 'Email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>

    <div class="form-group">
        {!! Form::submit('Actualizar', ['class' => 'btn btn-primary']) !!}
		{!! Form::reset('Limpar', ['class' => 'btn btn-danger']) !!}
    </div>
    {!! Form::close() !!}
@stop
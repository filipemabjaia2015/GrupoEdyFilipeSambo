@extends('layout/template')

@section('content')
 <h1>DK Participante</h1>
 <a href="{{url('/participantes/create')}}" class="btn btn-success">Registar Participante</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>Id</th>
         <th>Nome</th>
         <th>Apelido</th>
         <th>Nivel</th>
         <th>Empresa</th>
         <th>Genero</th>
		 <th>Idade</th>
		 <th>Email</th>
         <th colspan="3">Actions</th>
     </tr>
     </thead>
     <tbody>
     @foreach ($participantes as $participante)
         <tr>
             <td>{{ $participante->id}}</td>
             <td>{{ $participante->nome }}</td>
             <td>{{ $participante->apelido }}</td>
             <td>{{ $participante->nivel }}</td>
             <td>{{ $participante->empresa }}</td>
			 <td>{{ $participante->genero }}</td>
			 <td>{{ $participante->idade }}</td>
			 <td>{{ $participante->email }}</td>
             <td><img src="{{asset('img/'.$participante->image.'.jpg')}}" height="35" width="30"></td>
             <td><a href="{{url('participantes',$participante->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('participantes.edit',$participante->id)}}" class="btn btn-warning">Update</a></td>
             <td>
             {!! Form::open(['method' => 'DELETE', 'route'=>['participantes.destroy', $participante->id]]) !!}
             {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
             {!! Form::close() !!}
             </td>
         </tr>
     @endforeach

     </tbody>

 </table>
@endsection
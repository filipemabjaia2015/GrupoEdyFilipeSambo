 <!--
Design by Bryant Smith
http://www.bryantsmith.com
http://www.aszx.net
email: templates [-at-] bryantsmith [-dot-] com
Released under Creative Commons Attribution 2.5 Generic.  In other words, do with it what you please; but please leave the link if you'd be so kind :)

Name       : The Slant
Version    : 1.0
Released   : 2009-07-25
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<title>DK Eventos</title>
</head>

<body>
    <div id="page">
		
        <div id="header">
        	<h1 <a href="paginaInicial">DK Eventos</h1>
            <ul>
           	   	<li><a href="paginaInicial">Home</a></li>
               	<li><a href="produtos">Eventos</a></li>
                <li><a href="servicos">Participantes</a></li>
                <li><a href="contacto">Serviços </a></li>
				<li><a href="logs">Contactos</a></li>
            </ul>
        </div>
  
       <div id="main">
         <p>
        	<div class="main_top">
            	
				<h1> Prestamos os seguintes serviços  de Qualidade....</h1>
            </div>
             
           	<div class="main_body">
			
				<p>

					* Festival</br>
					* Casamentos</br>
					* Batizados</br>
					* Aniversarios</br>
					* E outros...</br>
					
				</p>
			
            </div>
            
           	<div class="main_bottom"></div>
            
        </div>
        
        
        
        <div id="footer">
        <p>
        <a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a>
        </p>
        </div>
        
        </div>
</body>
</html>

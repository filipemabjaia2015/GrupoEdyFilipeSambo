@extends('layout/template')
@section('content')
    <h1>Mostrar Participantes</h1>

    <form class="form-horizontal">
        <div class="form-group">
            <label for="image" class="col-sm-2 control-label">Cover</label>
            <div class="col-sm-10">
                <img src="{{asset('img/'.$participante->image.'.jpg')}}" height="180" width="150" class="img-rounded">
            </div>
        </div>
        <div class="form-group">
            <label for="nome" class="col-sm-2 control-label">Nome</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="nome" placeholder={{$participante->nome}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="apelido" class="col-sm-2 control-label">Apelido</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="apelido" placeholder={{$participante->apelido}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="nivel" class="col-sm-2 control-label">Nivel</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="nivel" placeholder={{$participante->nivel}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="empresa" class="col-sm-2 control-label">Empresa</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="empresa" placeholder={{$participante->empresa}} readonly>
            </div>
        </div>

		<div class="form-group">
            <label for="genero" class="col-sm-2 control-label">Genero</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="genero" placeholder={{$participante->genero}} readonly>
            </div>
        </div>
		<div class="form-group">
            <label for="idade" class="col-sm-2 control-label">Idade</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="idade" placeholder={{$participante->idade}} readonly>
            </div>
        </div>
		<div class="form-group">
            <label for="email" class="col-sm-2 control-label">Email</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="Email" placeholder={{$participante->email}} readonly>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('participantes')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
@stop
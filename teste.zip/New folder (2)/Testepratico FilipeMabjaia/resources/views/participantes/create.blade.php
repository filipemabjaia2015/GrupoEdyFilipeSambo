@extends('layout.template')
@section('content')
    <h1>Create Participante</h1>
    {!! Form::open(['url' => 'participantes']) !!}
    <div class="form-group">
        {!! Form::label('Nome', 'Nome:') !!}
		</div>

        {!! Form::text('nome',null,['class'=>'form-primary']) !!}

    <div class="form-group">
        {!! Form::label('Apelido', 'Apelido:') !!}
		</div>
	<div class="form-group">
        {!! Form::text('apelido',null,['class'=>'form-primary']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Nivel', 'Nivel:') !!}</div>
	<div class="form-group">
        {!! Form::text('nivel',null,['class'=>'form-primary']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Empresa', 'Empresa:') !!}
		</div>
	<div class="form-group">
        {!! Form::text('empresa',null,['class'=>'form-primary']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Genero', 'Genero:') !!}
		</div>
	<div class="form-group">
        {!! Form::text('genero',null,['class'=>'form-primary']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Idade', 'Idade:') !!}
	
		</div>
	<div class="form-group">
        {!! Form::text('idade',null,['class'=>'form-primary']) !!}
    </div>	
    <div class="form-group">
        {!! Form::label('Email', 'Email:') !!}
        {!! Form::text('email',null,['class'=>'form-primary']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
		{!! Form::reset('Limpar', ['class' => 'btn btn-danger']) !!}
    </div>
    {!! Form::close() !!}
@stop
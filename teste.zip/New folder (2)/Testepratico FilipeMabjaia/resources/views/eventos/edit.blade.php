@extends('layout.template')
@section('content')
    <h1>Update Evento</h1>
    {!! Form::model($evento,['method' => 'PATCH','route'=>['eventos.update',$evento->id]]) !!}
    <div class="form-group">
        {!! Form::label('Titulo', 'Titulo:') !!}
        {!! Form::text('titulo',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Tipo', 'Tipo:') !!}
        {!! Form::text('tipo',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Descricao', 'Descricao:') !!}
        {!! Form::text('descricao',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Local', 'Local:') !!}
        {!! Form::text('local',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('Agenda', 'Agenda:') !!}
        {!! Form::text('agenda',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Actualizar', ['class' => 'btn btn-primary']) !!}
		{!! Form::reset('Limpar', ['class' => 'btn btn-danger']) !!}
    </div>
    {!! Form::close() !!}
@stop
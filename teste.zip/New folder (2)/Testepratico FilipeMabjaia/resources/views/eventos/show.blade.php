@extends('layout/template')
@section('content')
    <h1>Evento Show</h1>

    <form class="form-horizontal">
        <div class="form-group">
            <label for="image" class="col-sm-2 control-label">Cover</label>
            <div class="col-sm-10">
                <img src="{{asset('img/'.$evento->image.'.jpg')}}" height="180" width="150" class="img-rounded">
            </div>
        </div>
        <div class="form-group">
            <label for="titulo" class="col-sm-2 control-label">Titulo</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="titulo" placeholder={{$evento->titulo}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="tipo" class="col-sm-2 control-label">Tipo</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="tipo" placeholder={{$evento->tipo}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="descricao" class="col-sm-2 control-label">descricao</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="cescricao" placeholder={{$evento->descricao}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="local" class="col-sm-2 control-label">Local</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="local" placeholder={{$evento->local}} readonly>
            </div>
        </div>

		<div class="form-group">
            <label for="agenda" class="col-sm-2 control-label">Agenda</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="agenda" placeholder={{$evento->agenda}} readonly>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('eventos')}}" class="btn btn-primary">Voltar</a>
            </div>
        </div>
    </form>
@stop